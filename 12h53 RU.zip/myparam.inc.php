<?php
define("MYHOST", "10.1.16.56/oracle2");
define("MYUSER", "haceneourlis");
define("MYPASS", "oracle");
